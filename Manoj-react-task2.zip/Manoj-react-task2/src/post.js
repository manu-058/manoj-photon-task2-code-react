import React, { useEffect, useState } from "react";
import PostForm, { FRESH_POST } from "./post-form";

function Post() {
  const [postList, setPostList] = useState([]);
  const [editItem, setEditItem] = useState(FRESH_POST);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    // Load the post list
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((data) => data.json())
      .then((data) => {
        setPostList(data);
      });
  }, []);

  const editClickHandler = (id) => {
    const _editItem = postList.find((item) => item.id == id);
    setEditItem({ ..._editItem });
    setShowForm(true);
  };

  const addPostClickHandler = () => {
    setEditItem({ ...FRESH_POST });
    setShowForm(true);
  };

  const deletePostClickHandler = (id) => {
    // delete post , make call
    const _updatedPost = postList.filter((item) => item.id != id);
    setPostList([..._updatedPost]);
  };

  const submitHandler = (data) => {
    if (data.id === "new") {
      // adding new item to list,
      setPostList([data, ...postList]);
    } else {
      const _updatedList = postList.map((item) => {
        if (item.id == data.id) return data;
        return item;
      });
      setPostList([..._updatedList]);
    }
  };

  return (
    <div>
      {showForm && (
        <PostForm data={editItem} close={setShowForm} submit={submitHandler} />
      )}
      <button onClick={addPostClickHandler}>Add +</button>
      <div className="post-list-container">
        {postList.map((item) => {
          return (
            <div className="list-item" key={item.id}>
              <div className="list-item-header">
                <div>{item.title}</div>
                <div className="spacer"></div>
                <div className="action">
                  <button onClick={() => editClickHandler(item.id)}>
                    Edit
                  </button>
                  <button onClick={() => deletePostClickHandler(item.id)}>
                    Delete
                  </button>
                </div>
              </div>
              <div className="list-item-body">{item.body}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default Post;

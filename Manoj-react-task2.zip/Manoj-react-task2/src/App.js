import "./styles.css";
import Post from "./post";

export default function App() {
  return (
    <div className="App">
      <Post />
    </div>
  );
}

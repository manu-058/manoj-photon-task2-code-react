import React, { useEffect, useState } from "react";

export const FRESH_POST = {
  userId: "",
  title: "",
  body: "",
  id: "new",
};
function PostForm(props) {
  const [postFormDetails, setPostFormDetails] = useState(FRESH_POST);

  useEffect(() => {
    // Edit Operation load data
    setPostFormDetails({ ...props.data });
  }, [props.data]);

  const closeHamdler = () => {
    props.close(false);
  };

  const changeEventHandler = (nexText, field) => {
    const _updatedForm = { ...postFormDetails, [field]: nexText };
    setPostFormDetails({ ..._updatedForm });
  };

  const submitForm = () => {
    props.submit(postFormDetails);
    closeHamdler();
  };

  return (
    <div className="overlay">
      <div className="form-container">
        <div className="list-item-header">
          <div>{props.data.id == "" ? "Add Form" : "Edit Form"}</div>
          <div className="spacer"></div>
          <div className="action">
            <button onClick={submitForm}>Submit</button>
            <button onClick={closeHamdler}>Close</button>
          </div>
        </div>
        <div className="post-form">
          {`User ID: ${postFormDetails.userId}`}
          <div clasName="fileds">
            <div>Title:</div>
            <input
              className="form-width"
              onChange={(event) =>
                changeEventHandler(event.target.value, "title")
              }
              value={postFormDetails.title}
              placeholder="title"
            />
          </div>
          <div clasName="fileds">
            <div>Description:</div>
            <textarea
              className="form-width"
              rows={5}
              onChange={(event) =>
                changeEventHandler(event.target.value, "body")
              }
              value={postFormDetails.body}
              placeholder="details"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default PostForm;
